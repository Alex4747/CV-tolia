function createDiv() {
    let qwe = document.createElementById('');
    qwe.innerText = document.getElementById('getText').innerText;
    document.body.appendChild(qwe);
  }